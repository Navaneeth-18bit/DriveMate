using Microsoft.AspNetCore.Mvc;
using adminPage.Models;
using System.Linq;

namespace adminPage.Controllers
{
    public class AuthController : Controller
    {
        private readonly DriveMateDbContext _context;

        public AuthController(DriveMateDbContext context)
        {
            _context = context;
        }

        // 🔹 Login Page
        public IActionResult Login()
        {
            return View();
        }

        // 🔹 Handle Login
        [HttpPost]
        public IActionResult Login(Admin admin)
        {
            var user = _context.Admins
                .FirstOrDefault(a => a.Username == admin.Username 
                                  && a.Password == admin.Password);

            if (user != null)
            {
                // Simple session login
                HttpContext.Session.SetString("Admin", user.Username);
                return RedirectToAction("Index", "Home");
            }

            ViewBag.Error = "Invalid username or password";
            return View();
        }

        // 🔹 Logout
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }
    }
}