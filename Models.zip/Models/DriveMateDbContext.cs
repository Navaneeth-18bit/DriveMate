using System;
using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;
using adminPage.Models;
using System.Linq;


public class DriveMateDbContext : DbContext
{
    public DriveMateDbContext(DbContextOptions<DriveMateDbContext> options)
        : base(options)
    {
    }

    public DbSet<User> Users { get; set; } = null!;

    public DbSet<Driver> Drivers { get; set; } = null!;

    public DbSet<Admin> Admins { get; set; } = null!;
}